module Main where

import Lib

main = putStrLn("sdsd")
